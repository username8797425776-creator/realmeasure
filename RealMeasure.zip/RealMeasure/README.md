# RealMeasure (starter)
Open this folder in Android Studio (Koala+), sync Gradle, run on a physical phone.

## How it measures
Ground-plane trigonometry: phone height (slider) + pitch sensor + the object's box in the frame
-> distance (from the box's bottom edge), height (from the top edge), speed (tracked ground position / time).
Assumptions: object stands on level ground, phone is held steady. Set Measurer.vFovDeg to your camera's real vertical FOV.
If distances look inverted, flip PITCH_SIGN in CameraAnalyzer.kt.

## Next steps for better accuracy
Calibrate FOV (checkerboard), add ARCore Depth / LiDAR-class depth, Kalman filter for speed.
