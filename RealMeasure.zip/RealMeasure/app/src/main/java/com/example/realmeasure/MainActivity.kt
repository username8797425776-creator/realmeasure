package com.example.realmeasure

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val dark = androidx.compose.foundation.isSystemInDarkTheme()
            val ctx = LocalContext.current
            MaterialTheme(colorScheme = if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text("RealMeasure") }) }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (granted) MeasureScreen() else
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Camera permission needed")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Grant") }
                }
        }
    }
}

@Composable
fun MeasureScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val measurer = remember { Measurer() }
    val sensor = remember { PitchSensor(ctx) }
    var results by remember { mutableStateOf(emptyList<Measurement>()) }
    var aspect by remember { mutableFloatStateOf(3f / 4f) }
    var camH by remember { mutableFloatStateOf(1.5f) }
    LaunchedEffect(camH) { measurer.camHeightM = camH }

    DisposableEffect(Unit) { sensor.start(); onDispose { sensor.stop() } }

    val primary = results.filter { it.distanceM != null }.maxByOrNull { (it.r - it.l) * (it.b - it.t) }

    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(28.dp)), contentAlignment = Alignment.Center) {
            Box(Modifier.aspectRatio(aspect)) {
                AndroidView(modifier = Modifier.fillMaxSize(), factory = { c ->
                    PreviewView(c).apply { scaleType = PreviewView.ScaleType.FIT_CENTER }.also { pv ->
                        val fut = ProcessCameraProvider.getInstance(c)
                        fut.addListener({
                            val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
                            val analysis = ImageAnalysis.Builder()
                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                                .also { it.setAnalyzer(Executors.newSingleThreadExecutor(),
                                    DetectAnalyzer(measurer, sensor) { r, a -> results = r; aspect = a }) }
                            val p = fut.get()
                            p.unbindAll()
                            p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                        }, ContextCompat.getMainExecutor(c))
                    }
                })
                val color = MaterialTheme.colorScheme.primary
                Canvas(Modifier.fillMaxSize()) {
                    results.forEach { m ->
                        val sel = m.id == primary?.id
                        drawRoundRect(color, Offset(m.l * size.width, m.t * size.height),
                            Size((m.r - m.l) * size.width, (m.b - m.t) * size.height),
                            CornerRadius(16f), style = Stroke(if (sel) 6f else 2f))
                    }
                }
            }
        }

        ElevatedCard(Modifier.fillMaxWidth().animateContentSize(spring(stiffness = Spring.StiffnessMediumLow))) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                AnimatedContent(primary, label = "metrics") { m ->
                    if (m == null) Text("Point the camera at an object standing on level ground",
                        style = MaterialTheme.typography.bodyMedium)
                    else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Metric(Icons.Filled.Height, "Height", m.heightM ?: 0f, "m")
                        Metric(Icons.Filled.Straighten, "Distance", m.distanceM ?: 0f, "m")
                        Metric(Icons.Filled.Speed, "Speed", m.speedMps * 3.6f, "km/h")
                    }
                }
                primary?.let { AssistChip(onClick = {}, label = { Text("Estimated error ±${"%.0f".format(it.errorPct)}%") }) }
                Text("Your phone height: ${"%.2f".format(camH)} m", style = MaterialTheme.typography.labelLarge)
                Slider(value = camH, onValueChange = { camH = it }, valueRange = 0.5f..2.2f)
            }
        }
    }
}

@Composable
fun Metric(icon: ImageVector, label: String, value: Float, unit: String) {
    val v by animateFloatAsState(value, spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessLow), label = label)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Text("${"%.2f".format(v)} $unit", style = MaterialTheme.typography.titleLarge)
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}
