package com.example.realmeasure

import kotlin.math.*

data class Measurement(
    val id: Int, val l: Float, val t: Float, val r: Float, val b: Float, // normalized 0..1
    val distanceM: Float?, val heightM: Float?, val speedMps: Float, val errorPct: Float
)

/**
 * Ground-plane geometry: phone held at camHeightM, object standing on level ground.
 * Needs: phone pitch (sensor), vertical FOV of the camera, and the object's box.
 */
class Measurer(var camHeightM: Float = 1.5f, var vFovDeg: Float = 60f) {
    private class Track(var x: Float, var y: Float, var tNs: Long, var speed: Float, var dist: Float)
    private val tracks = HashMap<Int, Track>()

    fun measure(id: Int, l: Float, t: Float, r: Float, b: Float,
                aspect: Float, pitchRad: Float, tNs: Long): Measurement {
        val fy = 0.5f / tan(Math.toRadians(vFovDeg / 2.0)).toFloat() // focal length in frame-heights
        fun elev(yn: Float) = pitchRad + atan((0.5f - yn) / fy)

        val eb = elev(b)
        if (eb > -0.02f) return Measurement(id, l, t, r, b, null, null, 0f, 100f) // base at/above horizon

        val raw = camHeightM / tan(-eb)
        val tr = tracks.getOrPut(id) { Track(0f, 0f, 0L, 0f, raw) }
        tr.dist = if (tr.tNs == 0L) raw else tr.dist + 0.3f * (raw - tr.dist) // smooth
        val d = tr.dist
        val height = max(0f, camHeightM + d * tan(elev(t)))

        val az = atan((((l + r) / 2f - 0.5f) * aspect) / fy)
        val x = d * sin(az); val y = d * cos(az)
        if (tr.tNs != 0L) {
            val dt = (tNs - tr.tNs) / 1e9f
            if (dt > 0.05f) {
                val v = hypot(x - tr.x, y - tr.y) / dt
                tr.speed += 0.2f * (v - tr.speed)
                tr.x = x; tr.y = y; tr.tNs = tNs
            }
        } else { tr.x = x; tr.y = y; tr.tNs = tNs }

        val err = (2f + d * 1.5f).coerceAtMost(99f) // rough: pitch error grows with range
        if (tracks.size > 50) tracks.keys.take(25).forEach { tracks.remove(it) }
        return Measurement(id, l, t, r, b, d, height, tr.speed, err)
    }
}
