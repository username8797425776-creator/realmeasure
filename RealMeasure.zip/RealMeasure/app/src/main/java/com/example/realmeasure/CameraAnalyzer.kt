package com.example.realmeasure

import android.content.Context
import android.hardware.*
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions

class PitchSensor(ctx: Context) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    @Volatile var pitchRad = 0f // + = camera tilted up. If reversed on your device, flip PITCH_SIGN.
    fun start() { sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR), SensorManager.SENSOR_DELAY_GAME) }
    fun stop() = sm.unregisterListener(this)
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onSensorChanged(e: SensorEvent) {
        val m = FloatArray(9); val m2 = FloatArray(9); val o = FloatArray(3)
        SensorManager.getRotationMatrixFromVector(m, e.values)
        SensorManager.remapCoordinateSystem(m, SensorManager.AXIS_X, SensorManager.AXIS_Z, m2)
        SensorManager.getOrientation(m2, o)
        pitchRad = PITCH_SIGN * -o[1]
    }
    companion object { const val PITCH_SIGN = 1f }
}

class DetectAnalyzer(
    private val measurer: Measurer, private val sensor: PitchSensor,
    private val onResult: (List<Measurement>, Float) -> Unit
) : ImageAnalysis.Analyzer {
    private val detector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableMultipleObjects().build()
    )

    @androidx.camera.core.ExperimentalGetImage
    override fun analyze(proxy: ImageProxy) {
        val img = proxy.image ?: return proxy.close()
        val rot = proxy.imageInfo.rotationDegrees
        val w = (if (rot % 180 == 0) proxy.width else proxy.height).toFloat()
        val h = (if (rot % 180 == 0) proxy.height else proxy.width).toFloat()
        val pitch = sensor.pitchRad
        val ts = proxy.imageInfo.timestamp
        detector.process(InputImage.fromMediaImage(img, rot))
            .addOnSuccessListener { list ->
                val out = list.mapNotNull { o ->
                    val id = o.trackingId ?: return@mapNotNull null
                    val bb = o.boundingBox
                    measurer.measure(id, bb.left / w, bb.top / h, bb.right / w, bb.bottom / h, w / h, pitch, ts)
                }
                onResult(out, w / h)
            }
            .addOnCompleteListener { proxy.close() }
    }
}
